function foo() {
    return "foo";
}