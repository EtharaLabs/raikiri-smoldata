// State Management

import { reactive, watch } from "vue";

// Parse and validate a string[] from localStorage, returning [] on any invalid value.
const storageToStringArray = (key) => {
	try {
		const raw = localStorage.getItem(key);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		if (Array.isArray(parsed) && parsed.every((v) => typeof v === "string")) {
			return parsed;
		}
	} catch {
		// ignore malformed JSON
	}
	return [];
};

// global mailbox info
export const mailbox = reactive({
	total: 0, // total number of messages in database
	unread: 0, // total unread messages in database
	count: 0, // total in mailbox or search
	messages: [], // current messages
	tags: [], // all tags
	selected: [], // currently selected
	connected: false, // websocket connection
	searching: false, // current search, false for none
	refresh: false, // to listen from MessagesMixin
	autoPaginating: true, // allows temporary bypass of loadMessages() via auto-pagination
	notificationsSupported: false, // browser supports notifications
	notificationsEnabled: false, // user has enabled notifications
	skipConfirmations: false, // skip modal confirmations for "Delete all" & "mark all read"
	appInfo: {}, // application information
	uiConfig: {}, // configuration for UI
	lastMessage: false, // return scrolling
	defaultReleaseAddresses: storageToStringArray("defaultReleaseAddresses"), // default release addresses for released messages

	// settings
	showTagColors: !localStorage.getItem("hideTagColors"),
	showHTMLCheck: !localStorage.getItem("hideHTMLCheck"),
	showLinkCheck: !localStorage.getItem("hideLinkCheck"),
	showSpamCheck: !localStorage.getItem("hideSpamCheck"),
	timeZone: localStorage.getItem("timeZone")
		? localStorage.getItem("timeZone")
		: Intl.DateTimeFormat().resolvedOptions().timeZone,
	showAttachmentDetails: localStorage.getItem("showAttachmentDetails"), // show attachment details
});

watch(
	() => mailbox.count,
	() => {
		mailbox.selected = [];
	},
);

watch(
	() => mailbox.showTagColors,
	(v) => {
		if (v) {
			localStorage.removeItem("hideTagColors");
		} else {
			localStorage.setItem("hideTagColors", "1");
		}
	},
);

watch(
	() => mailbox.showHTMLCheck,
	(v) => {
		if (v) {
			localStorage.removeItem("hideHTMLCheck");
		} else {
			localStorage.setItem("hideHTMLCheck", "1");
		}
	},
);

watch(
	() => mailbox.showLinkCheck,
	(v) => {
		if (v) {
			localStorage.removeItem("hideLinkCheck");
		} else {
			localStorage.setItem("hideLinkCheck", "1");
		}
	},
);

watch(
	() => mailbox.showSpamCheck,
	(v) => {
		if (v) {
			localStorage.removeItem("hideSpamCheck");
		} else {
			localStorage.setItem("hideSpamCheck", "1");
		}
	},
);

watch(
	() => mailbox.defaultReleaseAddresses,
	(v) => {
		if (v.length) {
			localStorage.setItem("defaultReleaseAddresses", JSON.stringify(v));
		} else {
			localStorage.removeItem("defaultReleaseAddresses");
		}
	},
);

watch(
	() => mailbox.timeZone,
	(v) => {
		if (v === Intl.DateTimeFormat().resolvedOptions().timeZone) {
			localStorage.removeItem("timeZone");
		} else {
			localStorage.setItem("timeZone", v);
		}
	},
);

watch(
	() => mailbox.showAttachmentDetails,
	(v) => {
		if (v) {
			localStorage.setItem("showAttachmentDetails", "1");
		} else {
			localStorage.removeItem("showAttachmentDetails");
		}
	},
);
